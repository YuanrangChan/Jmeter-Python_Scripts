import java.text.SimpleDateFormat;
import java.util.Date;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
	String time17 = sdf.format(new Date());
	vars.put("date",time17.substring(0, 14));
	vars.put("ymd",time17.substring(0, 8));
	System.out.println(time17+" 长度为："+time17.length()+" 字符类型："+time17.getClass().toString());
	int n = 10;
	
	//构建EC订购的
	
	//构造oprseq,计数器在单个线程内是唯一的
	String oprseq_bip2b958 = String.valueOf(${OWNER}+"1BIP2B958"+time17+"${number}");
	vars.put("oprseq_bip2b958",oprseq_bip2b958);
	String oprseq_bip2b956 = String.valueOf(${OWNER}+"1BIP2B956"+time17+"${number}");
	vars.put("oprseq_bip2b956",oprseq_bip2b958);
	String oprseq_bip2b960 = String.valueOf(${OWNER}+"1BIP2B960"+time17+"${number}");
	vars.put("oprseq_bip2b960",oprseq_bip2b960);#此处应该是错写成958，改过来就成功了。
	String oprseq_bip2b962 = String.valueOf(${OWNER}+"1BIP2B962"+time17+"${number}");
	vars.put("oprseq_bip2b962",oprseq_bip2b958);
	
	//设置APN1的参数，就是配置给APN的基础服务产品是93还是92等
	vars.put("ApnServiceProd","I"+"${ServiceID}".substring(1, 12));
	
	String SubsID = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID1  = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID2  = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID3  = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID4  = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID5  = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID6  = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID7  = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID8  = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID9  = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID10 = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID11 = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID12 = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID13 = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID14 = "9" + ${OWNER} + time17.substring(2, 14) + (n++);
	String ProdInstID15 = "9" + ${OWNER} + time17.substring(2, 14) + (n++);

	vars.put("SubsID",SubsID);
   	vars.put("ProdInstID1",ProdInstID1);vars.put("ProdInstID2",ProdInstID2);
   	vars.put("ProdInstID3",ProdInstID3);vars.put("ProdInstID4",ProdInstID4);
	vars.put("ProdInstID5",ProdInstID5);vars.put("ProdInstID6",ProdInstID6);
	vars.put("ProdInstID7",ProdInstID7);vars.put("ProdInstID8",ProdInstID8);
	vars.put("ProdInstID9",ProdInstID9);vars.put("ProdInstID10",ProdInstID10);
	vars.put("ProdInstID11",ProdInstID11);vars.put("ProdInstID12",ProdInstID12);
   	vars.put("ProdInstID13",ProdInstID13);vars.put("ProdInstID14",ProdInstID14);
   	vars.put("ProdInstID15",ProdInstID15);
	System.out.println(SubsID + "==" + ProdInstID1 + "==" + ProdInstID8);

	//计数器如果直接${counter1}这样使用，即使你设置了number format为000，仍然当成数字来用,，只能通过""去转换使用；
	System.out.println("计数器："+"${number}");
	System.out.println("计数器："+"${number}");

	//通过${}方式取到的变量值维持元类型，但是如果通过vars.get()--本质上就是map(string,string)，取到的只能是字符串
	System.out.println(String.valueOf(${OWNER}+200));
	String owner1 =vars.get("OWNER")+1;
	System.out.println(owner1);
	